<?php
include "conn.php";
if($_SERVER['REQUEST_METHOD']=="POST"){
$name=$_POST['name'];
$email=$_POST['email'];
$c_number=$_POST['c_number'];
$email_owner=$_POST['email_owner'];
$number_owner=$_POST['number_owner'];
$days=$_POST['days'];
$date=$_POST['date'];
$price=$_POST['price'];
$totalrent=$days*$price;
$car_model=$_POST['car_model'];
$v_number=$_POST['car_number'];


$sql="INSERT INTO `order_car` (`c_name`, `c_email`, `c_number`, `days`, `date`, `car_model`, `car_number` , `price`, `c_status`, `email_owner`, `number_owner`, `res`) VALUES ('$name', '$email', '$c_number', '$days', '$date', '$car_model', '$v_number', '$totalrent', 'booking', '$email_owner', '$number_owner', '0') ";

$result=mysqli_query($conn,$sql);
if($result){
    
    session_start();
$_SESSION['name']=$name;
$_SESSION['email']=$email;
$_SESSION['c_number']=$c_number;
$_SESSION['price']=$totalrent;


?>






<!-- <script type="text/javascript">
alert("Order Booked");

    </script>
    -->

 <script type="text/javascript">


       window.location.href="payscript.php";
       
       
    </script>
    
    <?php
    
     
}



}
    
    



?>